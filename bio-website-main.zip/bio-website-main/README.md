- 👋 Hi, I’m @yxhaa
- 👀 I’m interested in web development
- 🌱 I’m currently learning css, html, javascript
- 📫 How to reach me yxha on discord

this is my first website i am developing.
